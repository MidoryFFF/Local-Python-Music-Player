import { notFound } from "next/navigation";

import { TrackScreen } from "@/components/track-screen";
import { allTracks } from "@/lib/data";

export function generateStaticParams() {
  return allTracks.map((track) => ({ id: track.id }));
}

export default function TrackPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  return <TrackPageContent paramsPromise={params} />;
}

async function TrackPageContent({
  paramsPromise,
}: {
  paramsPromise: Promise<{ id: string }>;
}) {
  const { id } = await paramsPromise;
  const track = allTracks.find((item) => item.id === id);
  if (!track) notFound();
  return <TrackScreen track={track} />;
}
