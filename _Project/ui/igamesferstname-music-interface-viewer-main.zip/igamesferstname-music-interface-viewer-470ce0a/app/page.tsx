import { LibraryView } from "@/components/library-view";
import { playlists } from "@/lib/data";

export default function HomePage() {
  return <LibraryView playlists={playlists} />;
}
