"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { Clock, ListMusic, Play, Search } from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { getCurrentPlaylist, type Playlist } from "@/lib/data";

function initials(title: string) {
  const words = title.trim().split(/\s+/);
  return words
    .slice(0, 2)
    .map((word) => word[0])
    .join("");
}

function normalize(value: string) {
  return value.trim().toLocaleLowerCase("ru");
}

export function LibraryView({ playlists }: { playlists: Playlist[] }) {
  const [activePlaylistId, setActivePlaylistId] = useState(
    () => getCurrentPlaylist().id
  );
  const [query, setQuery] = useState("");

  const activePlaylist =
    playlists.find((playlist) => playlist.id === activePlaylistId) ??
    playlists[0];

  const totalTracks = useMemo(
    () => playlists.reduce((total, p) => total + p.tracks.length, 0),
    [playlists]
  );

  const visibleTracks = useMemo(() => {
    const needle = normalize(query);
    if (!needle) return activePlaylist.tracks;
    return activePlaylist.tracks.filter((track) => {
      const haystack = normalize(`${track.title} ${track.artist}`);
      return haystack.includes(needle);
    });
  }, [activePlaylist, query]);

  return (
    <div className="min-h-[calc(100vh-4rem)]">
      <section className="relative overflow-hidden bg-background px-4 py-14 sm:py-20">
        <div className="pointer-events-none absolute inset-0 gradient-hero-vibrant pattern-grid opacity-90 [mask-image:radial-gradient(ellipse_at_top,black,transparent_70%)]" />
        <div className="relative mx-auto flex max-w-3xl flex-col items-center gap-5 text-center">
          <div className="inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-primary text-primary-foreground shadow-lg shadow-primary/30">
            <ListMusic className="h-7 w-7" />
          </div>
          <h1 className="text-3xl font-bold tracking-tight sm:text-5xl">
            Ваша музыкальная библиотека
          </h1>
          <p className="max-w-xl text-base text-muted-foreground sm:text-lg">
            Все композиции собраны в одном месте. Выбирайте плейлист, ищите
            любимые треки и управляйте воспроизведением.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
            {playlists.map((playlist) => (
              <Button
                key={playlist.id}
                variant={
                  playlist.id === activePlaylist.id ? "default" : "secondary"
                }
                size="sm"
                className="rounded-full px-4 py-1"
                onClick={() => setActivePlaylistId(playlist.id)}
              >
                {playlist.name}
              </Button>
            ))}
          </div>
        </div>
      </section>

      <section className="container mx-auto max-w-3xl px-4 pb-16">
        <Card>
          <CardHeader>
            <div className="flex items-start justify-between gap-4">
              <div>
                <CardTitle>{activePlaylist.name}</CardTitle>
                <p className="mt-0.5 text-sm text-muted-foreground">
                  {activePlaylist.description} · {visibleTracks.length} трека ·{" "}
                  {totalTracks} всего в библиотеке
                </p>
              </div>
              <Badge variant="outline" className="shrink-0">
                Заглушка
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="relative">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Поиск по названию или исполнителю"
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                className="pl-9"
                aria-label="Поиск треков"
              />
            </div>

            {visibleTracks.length === 0 ? (
              <div className="flex flex-col items-center gap-3 py-10 text-center">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-muted text-muted-foreground">
                  <Search className="h-5 w-5" />
                </div>
                <p className="text-sm text-muted-foreground">
                  Ничего не найдено по запросу «{query}»
                </p>
              </div>
            ) : (
              <div className="divide-y divide-border">
                {visibleTracks.map((track, index) => (
                  <Link
                    key={track.id}
                    href={`/track/${track.id}`}
                    className="group/track flex items-center gap-4 py-3"
                  >
                    <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg bg-secondary font-semibold text-secondary-foreground">
                      {initials(track.title)}
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate font-medium text-sm">
                        {track.title}
                      </p>
                      <p className="truncate text-sm text-muted-foreground">
                        {track.artist} · {track.album}
                      </p>
                    </div>
                    <div className="hidden items-center gap-3 sm:flex">
                      <span className="flex items-center gap-1.5 text-xs tabular-nums text-muted-foreground">
                        <Clock className="h-3.5 w-3.5" />
                        {track.duration}
                      </span>
                      <span className="inline-flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground opacity-0 transition-opacity group-hover/track:opacity-100">
                        <Play className="h-3.5 w-3.5 fill-current" />
                      </span>
                    </div>
                    <span className="text-sm tabular-nums text-muted-foreground sm:hidden">
                      {track.duration}
                    </span>
                    <span className="sr-only">
                      Порядковый номер {index + 1}
                    </span>
                  </Link>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </section>
    </div>
  );
}
