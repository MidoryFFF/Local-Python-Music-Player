"use client";

import {
  Pause,
  Play,
  SkipBack,
  SkipForward,
  Volume2,
  VolumeX,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { formatTime, usePlayer } from "@/components/player-provider";

type PlayerControlsProps = {
  className?: string;
  large?: boolean;
};

export function PlayerControls({
  className,
  large = false,
}: PlayerControlsProps) {
  const {
    isPlaying,
    position,
    duration,
    volume,
    nextTrack,
    prevTrack,
    togglePlay,
    seek,
    setVolume,
  } = usePlayer();

  const playButtonClass = large ? "h-14 w-14" : "h-10 w-10";
  const controlIconClass = large ? "h-6 w-6" : "h-4 w-4";
  const navButtonClass = large ? "h-10 w-10" : "h-8 w-8";

  return (
    <div className={className}>
      <div className="flex items-center justify-center gap-4">
        <Button
          variant="ghost"
          size="icon"
          className={navButtonClass}
          onClick={prevTrack}
          aria-label="Предыдущий трек"
        >
          <SkipBack className={controlIconClass} />
        </Button>
        <Button
          size="icon"
          className={`${playButtonClass} rounded-full`}
          onClick={togglePlay}
          aria-label={isPlaying ? "Пауза" : "Играть"}
        >
          {isPlaying ? (
            <Pause className={controlIconClass} fill="currentColor" />
          ) : (
            <Play className={controlIconClass} fill="currentColor" />
          )}
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className={navButtonClass}
          onClick={nextTrack}
          aria-label="Следующий трек"
        >
          <SkipForward className={controlIconClass} />
        </Button>
      </div>

      <div className="mt-3 flex items-center gap-3">
        <span className="shrink-0 text-xs tabular-nums text-muted-foreground">
          {formatTime(position)}
        </span>
        <Slider
          value={position}
          max={duration}
          step={1}
          onValueChange={(value) => typeof value === "number" && seek(value)}
          className="flex-1"
          aria-label="Прогресс воспроизведения"
        />
        <span className="shrink-0 text-xs tabular-nums text-muted-foreground">
          {formatTime(duration)}
        </span>
      </div>

      <div className="mt-3 flex items-center gap-2 sm:w-40 sm:mx-auto">
        {volume === 0 ? (
          <VolumeX className="h-4 w-4 shrink-0 text-muted-foreground" />
        ) : (
          <Volume2 className="h-4 w-4 shrink-0 text-muted-foreground" />
        )}
        <Slider
          value={volume}
          max={100}
          step={1}
          onValueChange={(value) =>
            typeof value === "number" && setVolume(value)
          }
          className="flex-1"
          thumbClassName="h-3 w-3"
          aria-label="Громкость"
        />
      </div>
    </div>
  );
}
