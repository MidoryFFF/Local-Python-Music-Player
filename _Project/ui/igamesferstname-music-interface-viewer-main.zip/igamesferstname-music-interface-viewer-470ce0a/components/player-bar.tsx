"use client";

import { usePlayer } from "@/components/player-provider";
import { PlayerControls } from "@/components/player-controls";

function initials(title: string) {
  const words = title.trim().split(/\s+/);
  return words
    .slice(0, 2)
    .map((word) => word[0])
    .join("");
}

export function PlayerBar() {
  const { track } = usePlayer();

  return (
    <div className="sticky bottom-0 z-40 border-t bg-background/80 backdrop-blur-md">
      <div className="mx-auto flex max-w-5xl flex-col gap-4 px-4 py-3 sm:flex-row sm:items-center sm:gap-6">
        <div className="flex min-w-0 items-center gap-3 sm:w-56">
          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg bg-primary/15 font-semibold text-primary">
            {initials(track.title)}
          </div>
          <div className="min-w-0">
            <p className="truncate text-sm font-medium">{track.title}</p>
            <p className="truncate text-xs text-muted-foreground">
              {track.artist} · {track.album}
            </p>
          </div>
        </div>

        <div className="min-w-0 flex-1">
          <PlayerControls />
        </div>
      </div>
    </div>
  );
}
