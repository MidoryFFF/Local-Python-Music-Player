"use client";

import { useEffect } from "react";
import Link from "next/link";
import { ArrowLeft, Disc3 } from "lucide-react";

import { Card, CardContent } from "@/components/ui/card";
import { buttonVariants } from "@/components/ui/button-variants";
import { cn } from "@/lib/utils";
import { usePlayer } from "@/components/player-provider";
import { PlayerControls } from "@/components/player-controls";
import type { Track } from "@/lib/data";

function initials(title: string) {
  const words = title.trim().split(/\s+/);
  return words
    .slice(0, 2)
    .map((word) => word[0])
    .join("");
}

export function TrackScreen({ track }: { track: Track }) {
  const { selectTrack } = usePlayer();

  useEffect(() => {
    selectTrack(track.id);
  }, [selectTrack, track.id]);

  return (
    <div className="min-h-[calc(100vh-4rem)]">
      <section className="relative overflow-hidden bg-background">
        <div className="pointer-events-none absolute inset-0 gradient-hero-vibrant pattern-grid opacity-90 [mask-image:radial-gradient(ellipse_at_top,black,transparent_70%)]" />
        <div className="relative mx-auto max-w-2xl px-4 py-10 sm:py-14">
          <Link
            href="/"
            className={cn(
              buttonVariants({ variant: "ghost", size: "sm" }),
              "mb-8"
            )}
          >
            <ArrowLeft className="h-4 w-4" />
            Назад в библиотеку
          </Link>

          <Card className="overflow-hidden">
            <CardContent className="flex flex-col items-center gap-6 p-6 text-center sm:p-8">
              <div className="flex h-48 w-48 shrink-0 items-center justify-center rounded-2xl bg-primary/15 font-bold text-5xl text-primary shadow-lg shadow-primary/30 sm:h-56 sm:w-56">
                {initials(track.title)}
              </div>

              <div className="space-y-1.5">
                <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">
                  {track.title}
                </h1>
                <p className="text-base text-muted-foreground">
                  {track.artist}
                </p>
                <p className="flex items-center justify-center gap-1.5 text-sm text-muted-foreground">
                  <Disc3 className="h-4 w-4" />
                  {track.album}
                </p>
              </div>

              <p className="max-w-md text-sm leading-relaxed text-muted-foreground">
                {track.description}
              </p>

              <PlayerControls large className="w-full" />
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
}
