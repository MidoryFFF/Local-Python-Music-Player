"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";

import { allTracks, type Track } from "@/lib/data";

export function parseDuration(duration: string): number {
  const [minutes = "0", seconds = "0"] = duration.split(":");
  return Number(minutes) * 60 + Number(seconds);
}

export function formatTime(totalSeconds: number): string {
  const safe = Math.max(0, Math.floor(totalSeconds));
  const minutes = Math.floor(safe / 60);
  const seconds = safe % 60;
  return `${minutes}:${seconds.toString().padStart(2, "0")}`;
}

type PlayerContextValue = {
  track: Track;
  index: number;
  isPlaying: boolean;
  position: number;
  duration: number;
  volume: number;
  selectTrack: (trackId: string) => void;
  nextTrack: () => void;
  prevTrack: () => void;
  togglePlay: () => void;
  seek: (next: number) => void;
  setVolume: (volume: number) => void;
};

const PlayerContext = createContext<PlayerContextValue | null>(null);

export function PlayerProvider({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const [index, setIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [position, setPosition] = useState(0);
  const [volume, setVolume] = useState(70);
  const positionRef = useRef(0);

  const track = allTracks[index];
  const duration = parseDuration(track.duration);

  const seek = useCallback((next: number) => {
    positionRef.current = Math.max(0, Math.floor(next));
    setPosition(positionRef.current);
  }, []);

  useEffect(() => {
    if (!isPlaying) return;
    const id = setInterval(() => {
      const next = positionRef.current + 1;
      if (next >= parseDuration(allTracks[index].duration)) {
        setIsPlaying(false);
        positionRef.current = 0;
        setPosition(0);
        return;
      }
      positionRef.current = next;
      setPosition(next);
    }, 1000);
    return () => clearInterval(id);
  }, [isPlaying, index]);

  const changeTrack = useCallback(
    (nextIndex: number) => {
      setIndex((nextIndex + allTracks.length) % allTracks.length);
      seek(0);
    },
    [seek]
  );

  const selectTrack = useCallback(
    (trackId: string) => {
      const found = allTracks.findIndex((item) => item.id === trackId);
      if (found >= 0) changeTrack(found);
    },
    [changeTrack]
  );

  const nextTrack = useCallback(
    () => changeTrack(index + 1),
    [changeTrack, index]
  );

  const prevTrack = useCallback(() => {
    if (position > 3) {
      seek(0);
      return;
    }
    changeTrack(index - 1);
  }, [changeTrack, index, position, seek]);

  const togglePlay = useCallback(() => setIsPlaying((playing) => !playing), []);

  const value = useMemo<PlayerContextValue>(
    () => ({
      track,
      index,
      isPlaying,
      position,
      duration,
      volume,
      selectTrack,
      nextTrack,
      prevTrack,
      togglePlay,
      seek,
      setVolume,
    }),
    [
      track,
      index,
      isPlaying,
      position,
      duration,
      volume,
      selectTrack,
      nextTrack,
      prevTrack,
      togglePlay,
      seek,
    ]
  );

  return (
    <PlayerContext.Provider value={value}>{children}</PlayerContext.Provider>
  );
}

export function usePlayer(): PlayerContextValue {
  const context = useContext(PlayerContext);
  if (!context) {
    throw new Error("usePlayer must be used within a PlayerProvider");
  }
  return context;
}
