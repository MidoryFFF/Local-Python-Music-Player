export type Track = {
  id: string;
  title: string;
  artist: string;
  album: string;
  duration: string;
  description: string;
};

export type Playlist = {
  id: string;
  name: string;
  description: string;
  tracks: Track[];
};

export const playlists: Playlist[] = [
  {
    id: "favorites",
    name: "Избранное",
    description: "Треки, которые вы отметили",
    tracks: [
      {
        id: "t-1",
        title: "Северное сияние",
        artist: "Мира Светлова",
        album: "Полярные огни",
        duration: "3:42",
        description:
          "Спокойная инструментальная композиция о северном небе, полном всполохов света.",
      },
      {
        id: "t-2",
        title: "Тихий океан",
        artist: "Дальний Берег",
        album: "Течения",
        duration: "4:07",
        description:
          "Мечтательная баллада о бескрайних водах и чувстве свободы на просторе.",
      },
      {
        id: "t-3",
        title: "Полночный экспресс",
        artist: "Городские Огни",
        album: "Ночные маршруты",
        duration: "3:58",
        description:
          "Энергичный ритм ночного города и вагонов, уносящих в дальний путь.",
      },
      {
        id: "t-4",
        title: "Золотая осень",
        artist: "Листва",
        album: "Сезоны",
        duration: "5:12",
        description: "Тёплый акустический трек о листопаде и прощании с летом.",
      },
      {
        id: "t-5",
        title: "Медленный вальс",
        artist: "Анна Вержбицкая",
        album: "Паркет",
        duration: "4:25",
        description:
          "Нежная мелодия в медленном темпе под свет люстр танцевального зала.",
      },
    ],
  },
  {
    id: "chill",
    name: "Спокойная волна",
    description: "Расслабляющая музыка для отдыха",
    tracks: [
      {
        id: "t-6",
        title: "Дождь на стекле",
        artist: "Капли",
        album: "Влажность",
        duration: "3:19",
        description: "Деликатные капли дождя за окном, уют и тишина внутри.",
      },
      {
        id: "t-7",
        title: "Мягкий свет",
        artist: "Ламповый Радио",
        album: "Тёплые тона",
        duration: "4:03",
        description:
          "Мягкий ламповый звук и тёплые тона для спокойного вечера.",
      },
    ],
  },
  {
    id: "drive",
    name: "В дорогу",
    description: "Энергичные треки для пути",
    tracks: [
      {
        id: "t-8",
        title: "Ветер в лицо",
        artist: "Автострада",
        album: "Открытая дорога",
        duration: "3:31",
        description:
          "Задорная композиция для движения по открытой трассе с ветром в лицо.",
      },
      {
        id: "t-9",
        title: "Разгон",
        artist: "Турбо",
        album: "Высокая скорость",
        duration: "2:55",
        description:
          "Быстрый драйвовый трек с нарастающим темпом и мощным ритмом.",
      },
    ],
  },
];

export const currentPlaylistId = "favorites";

export const allTracks: Track[] = playlists.flatMap(
  (playlist) => playlist.tracks
);

export function getCurrentPlaylist(): Playlist {
  return (
    playlists.find((playlist) => playlist.id === currentPlaylistId) ??
    playlists[0]
  );
}

export function getTotalTracks(): number {
  return playlists.reduce(
    (total, playlist) => total + playlist.tracks.length,
    0
  );
}
